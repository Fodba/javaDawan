package fr.dawan.projweb.controleurs;

import java.io.IOException;

import javax.persistence.EntityManager;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import fr.dawan.projweb.dao.UtilisateurDao;
import fr.dawan.projweb.entites.Utilisateur;

/**
 * Servlet implementation class AuthentificationServlet
 */
@WebServlet("/AuthentificationServlet")
public class AuthentificationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AuthentificationServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		EntityManager em = MyStartupListener.getEmf().createEntityManager();
		// Récupération des paramètres
		String email = request.getParameter("email");
		String password = request.getParameter("password");

		String msg="";

		
		// Récupère l'utilisateur dans la BDD via l'email reçu dans la requête
		Utilisateur utilisateurDeBDD = UtilisateurDao.findByEmail(email, em, true);

		// Test sur les paramètres
		// test sur champs vides
		if(email == null || email.trim().isEmpty() || password == null || password.trim().isEmpty()) {

			msg = "Veuillez renseigner les champs";
			request.setAttribute("msg", msg);
			// redirection vers la même page
			request.getRequestDispatcher("authentification.jsp").forward(request, response);
		// test si les mot de passes correspondent
		} else if(utilisateurDeBDD != null && password.equals(utilisateurDeBDD.getPassword())) {
			
			// récupération de la session
			HttpSession session = request.getSession();
			session.setAttribute("userId", utilisateurDeBDD.getId());
			
			request.getRequestDispatcher("WEB-INF/session/accueil.jsp").forward(request, response);
		}
		// Autre exemple pour le else if
//		else if(password.equals(UtilisateurDao.findByEmail(email, em, true).getPassword())) {
//			
//		}
		// Si le couple email et mot de passe n'est pas correct
		else {
			msg = "Couple email / mot de passe incorrect";
			request.setAttribute("msg", msg);
			// redirection vers la même page
			request.getRequestDispatcher("authentification.jsp").forward(request, response);
	}
	

}

/**
 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
 */
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	// TODO Auto-generated method stub
	doGet(request, response);
}

}
