package fr.dawan.projetjaxrs.ws;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;

@Path("/bases")
public class BasesWS {

	@Context
	private HttpServletRequest request;

	@GET
	@Path("/hello1")
	@Produces("text/html;charset=UTF-8")
	public String sayHello() {
		return "MES DEBUTS EN JAX-RS";
	}
}