package fr.dawan.javaAppronfondissement;

import java.io.IOException;
import java.sql.SQLException;

import fr.dawan.dao.UtilisateurDao;
import fr.dawan.model.Utilisateur;
import fr.dawan.utils.ConnexionBDD;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	Utilisateur u = new Utilisateur();
    	u.setAdresse("monAdresse");
    	u.setLogin("Arnaud");
    	u.setNom("Delafont");
    	u.setPassword("pswd");
    	u.setPrenom("Arnaud");
    	u.setTelephone("012222222222");
    	
    	try {
			UtilisateurDao.inserer(u, ConnexionBDD.getConnection(), true);
		} catch (Exception e) {
			e.printStackTrace();
		} 
    }
}
