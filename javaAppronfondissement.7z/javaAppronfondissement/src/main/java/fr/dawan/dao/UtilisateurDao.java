package fr.dawan.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import fr.dawan.model.Utilisateur;

public class UtilisateurDao {

	// Méthodes CRUD (create read update delete)
	// Une méthode pour insérer des données dans la base de données
	public static int inserer(Utilisateur u, Connection cnx, boolean fermerCnx) throws SQLException {
		String sqlInsertion = "INSERT INTO utilisateur (identifiant, nom, prenom, adresse, telephone, login, password) VALUES (?,?,?,?,?,?,?)";
		
		PreparedStatement ps = cnx.prepareStatement(sqlInsertion);
		ps.setInt(1, (int) u.getIdentifiant());
		ps.setString(2, u.getNom());
		ps.setString(3, u.getPrenom());
		ps.setString(4, u.getAdresse());
		ps.setString(5, u.getTelephone());
		ps.setString(6, u.getLogin());
		ps.setString(7, u.getPassword());
		
		int result = ps.executeUpdate();
		
		if(fermerCnx) {
			cnx.close();
		}

		return result;
		
	}
	
	// Une méthode pour lire les données
	
	// Une méthode pour mettre à jour les données
	
	// Une méthode pour supprimer les données
	
}
