package fr.dawan.projweb.controleurs;

import java.io.IOException;

import javax.persistence.EntityManager;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import fr.dawan.projweb.dao.GenericDao;
import fr.dawan.projweb.entites.Utilisateur;

/**
 * Servlet implementation class LoadDataServlet
 */
@WebServlet("/LoadDataServlet")
public class LoadDataServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LoadDataServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		




		try {
			// Pour créer 10 utilisateurs
			for(int i = 0 ; i <10 ; i++) {
				
				// Création d'un EntityManager qui va gérer la connexion avec la BDD en une seule ligne
				EntityManager em = MyStartupListener.getEmf().createEntityManager();
				//Utilisateur u = new Utilisateur(0, 0, "nom" + i, "email@gmail.com" + i, "password" + i);

				// ci-dessous fait la même chose que l'appel au constructeur au-dessus

				Utilisateur u = new Utilisateur();
				u.setNom("nom" + i);
				u.setEmail("email" + i);
				u.setPassword("password" + i);


				GenericDao.saveOrUpdate(u, u.getId(), em, true);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		// Rediriger vers la même page
		request.getRequestDispatcher("index.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
