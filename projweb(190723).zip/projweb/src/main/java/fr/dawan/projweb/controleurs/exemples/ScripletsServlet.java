package fr.dawan.projweb.controleurs.exemples;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ScripletsServlet
 */
@WebServlet("/ScripletsServlet")
public class ScripletsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ScripletsServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		request.setAttribute("nom", request.getParameter("nom"));
//		request.setAttribute("prenom", request.getParameter("prenom"));
		
		//request.getSession();
		
		request.getRequestDispatcher("scripletsFormulaires.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		validateField("nom", request);
		validateField("prenom", request);
		
		doGet(request, response);
	}
	
	private void validateField(String nameField, HttpServletRequest request) {
		String valueField = request.getParameter(nameField);
		
		String nameFieldUpperCase = nameField.replace(nameField.substring(0,1), nameField.substring(0,1).toUpperCase());
		String msg ="";
		boolean error = false;
		
		if(valueField != null && !valueField.isEmpty()) {
			request.setAttribute(nameField, valueField);
			msg = nameFieldUpperCase + ": " + valueField ;
		} else {
			error=true;
			msg = "Le champ [" + nameField + "] est vide !";
			request.setAttribute(nameField, valueField);
		}
		request.setAttribute("error" + nameFieldUpperCase, error);
		request.setAttribute("msgError" + nameFieldUpperCase, msg);
	}

}
