package fr.dawan.classesEssentielles;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import fr.dawan.heritage.Chat;
import fr.dawan.heritage.Chien;

public class TestCollection {
	public static void main(String[] args) {
		
		// Convention quand on déclare une collection, toujours utilisé l'interface
		// pour gagner énormément de temps si jamais on a besoin de changer de type de collection
		List<Chat> maPremiereList = new ArrayList<Chat>();
		
		// Ajouter des éléments dans la liste
		maPremiereList.add(new Chat());
		maPremiereList.add(new Chat());
		maPremiereList.add(new Chat());
		System.out.println(maPremiereList.size());
		// Supprimer le dernier élément de ma liste
		maPremiereList.remove(maPremiereList.size()-1);
		System.out.println(maPremiereList.size());
		
		// Exactement comme une list mais sans doublon
		Set<Chat> maPremiereSet = new HashSet<Chat>();
		Chat chat = new Chat();
		maPremiereSet.add(chat);
		maPremiereSet.add(new Chat());
		maPremiereSet.add(new Chat());
		System.out.println(maPremiereSet.size());
		
		// Map pour associer n'importe quel type d'indice à un objet
		Chat monChatMap = new Chat("orange", "persan", 4, "monchat");
		Map<Chat, Chien> maPremiereMap = new HashMap<Chat, Chien>();
		maPremiereMap.put(monChatMap , new Chien());
		System.out.println(maPremiereMap.get(monChatMap));
	}
}
