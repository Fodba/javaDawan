package fr.dawan.classesEssentielles;

public class TestException {

	public static void main(String[] args) {
		
		// essaye d'exécuter le méthode susceptible de générer une exception
		try {
			double nouveauSolde = retrait(500.0, 50.0);
			System.out.println("Opération réussie");
		// Si j'ai une exception je rentre directement dans le catch
		} catch (Exception nomException) {
			// TODO Auto-generated catch block
			System.out.println(nomException.getMessage());
		}
		// finally optionnel
		finally {
			System.out.println("Opération terminée");
		}
	}
	
	public static double retrait(double solde, double montant) throws Exception {
		
		if(montant < solde) {
			return solde-montant;
		}
		else {
			throw new Exception("Solde insuffisant");
		}
	}

}
