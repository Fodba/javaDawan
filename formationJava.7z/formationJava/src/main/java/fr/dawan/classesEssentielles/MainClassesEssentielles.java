package fr.dawan.classesEssentielles;

public class MainClassesEssentielles {

	public static void main(String[] args) {
		
		
		// Manipulation des String directement sur l'objet String = Pas très optimisé
		String maString = "Corinne";
		
		// Renvoie la taille de la chaîne
		System.out.println(maString.length());
		//  Renvoie le caractère d'indice passé en paramètre
		System.out.println(maString.charAt(2));
		// Renvoie l'indice de la première correspondance dans le string
		System.out.println(maString.indexOf("re"));
		
		// Pour récupérer une partie de la String
		String s = "abcd".substring(2); //  renvoie cd
		String s1 = "abcd".substring(2,3); // renvoi c
		
		if(maString.contains("aure")) {
			System.out.println("c'est bien Laure");
		} else {
			System.out.println("Mais ou est Laure");
		}
		
		// remplacer une partie ou toute la chaine par une autre
		maString = maString.replace("Corinne", "  Olivier  ");
		System.out.println(maString);
		
		maString = maString.trim().replace("vier", "ta");
		System.out.println(maString);
		
		
		
		// Utiliser la classe StringBuilder = bcp plus optimisé
		StringBuilder maStringAvecStringBuilder = new StringBuilder("maString");
		maStringAvecStringBuilder.append(" je me colle à la String");
		
		String stringRecupererDepuisStringBuilder = maStringAvecStringBuilder.toString();
		System.out.println(stringRecupererDepuisStringBuilder);
		
		// Classe utilitaire pour les fonctions mathématiques
		// Math.abs(10)
	
	}

}
