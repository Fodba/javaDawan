package fr.dawan.exerciceHeritage;

// Classe fille, qui hérite de Vehicule avec le mot clé extends
// Une classe peut implémenté plusieurs interfaces
public class Avion extends Vehicule implements VehiculeAerien, VehiculeSousMarin {

	public Avion() {
		
	}
	
	// Redéfinition de la méthode abstraite
	// Est-ce que mon avion roule ?
	// Convention pour méthode qui retourne boolean la nom commence par is
	@Override
	public boolean isRoule() {
		return false;
	}

	public boolean isVolant() {
		return false;
	}

	public boolean isRouleFromInterface() {
		return false;
	}

	public boolean plonger() {
		return false;
	}

}
