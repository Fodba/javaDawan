package fr.dawan.manipulationfichier;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class ManipulationFichier {
	
	public static void main(String[] args) {
		
		try {
			ecrireDansFichier("C:/fichierTest.txt", "Coucou je suis en train d'écrire dans un fichier");
			System.out.println(lireDansFichier("C:/fichierTest.txt"));
		} catch (IOException e) {
			System.out.println("Fichier introuvable");
		}
		finally {
			System.out.println("Opération terminée");
		}
	}

	
	public static void ecrireDansFichier(String chemin, String line) throws IOException {
		File file = new File(chemin);
		
		// ! avoir le boolean contraire 
		// !false = true
		if(!file.exists()) {
			file.createNewFile();
		}
		
		// Overture du flux dans bw
		BufferedWriter bw = new BufferedWriter(new FileWriter(file, true));
		
		bw.write(line);
		bw.newLine();
		// Fermer mon flux (TRES IMPORTANT)
		bw.close();
		
	}
	
	
	public static String lireDansFichier(String chemin) throws IOException {
		File file = new File(chemin);
		
		String texteFichier = "";
		
		if(file.exists()) {
			
			// Ouverture du flux
			BufferedReader br = new BufferedReader(new FileReader(file));
			
			String str = br.readLine();
			while(str != null) {
				texteFichier = texteFichier + str + "\n";
				str = br.readLine();
			}
			
			// Fermer le flux
			br.close();
			
		}
		
		
		return texteFichier;
		
	}
}
