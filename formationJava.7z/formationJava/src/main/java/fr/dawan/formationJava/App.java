package fr.dawan.formationJava;

/**
 * Hello world!
 *
 */
public class App {



	public static void main(String[] args) {

		// Déclaration d'un tableau d'entier + taille fixe
		int[] tableauEntier  = new int[10];
		
		// Index commence à 0
		tableauEntier[0] = 10;
		tableauEntier[1] = 100;
		tableauEntier[2] = 10;
		tableauEntier[3] = 10;
		tableauEntier[4] = 10;
		tableauEntier[5] = 10;
		tableauEntier[6] = 50;
		tableauEntier[7] = 10;
		tableauEntier[8] = 10;
		tableauEntier[9] = 10;

		// Ne pas accéder à des cases qui n'existent pas
		//System.out.println(tableauEntier[10]);
		
		for(int i = 0 ; i < tableauEntier.length ; i++) {
			tableauEntier[i] = i;
			//System.out.println(tableauEntier[i]);
		}
		
		// foreach
		for(int caseDeMonTableau : tableauEntier) {
			System.out.println(caseDeMonTableau);
		}
		
		

		
		
		

		

		

	}

	static double division(double a, double b) {
		
		return (b==0) ? 0 : a/b;
	}
	
	static int choixOperation(int a , int b , char c) {
		int result;
		
		switch(c) {
		case '+' : 
			result = a+b;
			break;
		case '-' :
			result = a-b;
			break;
		case '/' :
			result = a/b;
			break;
		case '*' :
			result = a*b;
			break;
		default :
			result = 0;
		}
		
		return result;
	}
	
	static int choixOperationIfElse(int a , int b , char c) {
		int result;
		
		if(c == '+') {
			
			result = a+b;
			
		} else if (c == '-') {
			
			result = a-b;
			
		} else if (c == '/') {
			result = a/b;
		} else if( c== '*'){
			result = a*b;
		} else {
			result = 0;
		}
		
		return result;
	}

	static void boucleWhile() {
		int i=0;
		
		while(i < 10) {
			i++; // i = i +1
			System.out.println(i);
		}
		
		do {
			i++;
			System.out.println("Coucou from do while");
		}
		while(false);
		
		System.out.println("Boucle terminée ! ");
	}
	
	static void boucleFor() {
		
		// Quand on connaît le nombre d'itération
		for (int i = 0 ; i > 10 ; i++) {
			
		}
		
		// Parcourir l'ensemble des valeurs 
		
		
	}

}
