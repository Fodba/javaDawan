package fr.dawan.formationJava;

public class MaPremiereClasse {
	
	int nombreRoue;
	String marque;

	
	// Constructeur généré par défaut
	// Le constructeur permet de créer un objet du type de la classe
	MaPremiereClasse() {
		
	}
	
	// Constructeur surchargée qui prend en paramètre 2 variables
	MaPremiereClasse(int nombreRoue, String marque){
		this.nombreRoue = nombreRoue;
		this.marque = marque;
	}
	

	void afficherMarque() {
		System.out.println(marque);
	}
	
	void afficherMarque(int a) {
		
	}
	
	
	
}
