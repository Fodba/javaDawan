package fr.dawan.formationJava;

public class ExerciceTableau {

	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		
		System.out.println(args[1]);
		
		/* 
		 * 
		 * 
		 * 
		 * */ 
		
		
		
		// Tableau
		// Exemple 1D : taille à renseigner obligatoirement
		int[] tableau1D = new int[5];
		
		// Exemple 2D : taille à renseigner obligatoire pour la première dimension
		int[][] tableau2D = new int[10][25]; // pas de valeur pour le moment
		
		for(int i = 0 ; i <  tableau2D.length ; i++) { 
			
			for(int j = 0 ; j < tableau2D[i].length ; j++) {
				tableau2D[i][j] = i + j ;
				//System.out.println(tableau2D[i][j] + " ");
			}
			
		}
		
		
		// Déclaration + Initialisation d'un tableau à 2 D
		int[][] tableau2 = {{1,2}, {1}, {1,2,3}};
	}

}
