package fr.dawan.heritage;

public class Chien extends AnimalDomestique {

	// Redéfinition de la méthode de la classe mère
	public void communiquer() {
		System.out.println("Le chien dit wouaf!!");
	}
	
	
}
