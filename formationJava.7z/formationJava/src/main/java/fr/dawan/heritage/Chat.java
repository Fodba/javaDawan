package fr.dawan.heritage;

// Dans Java on ne peut hériter que d'une seule classe
// Héritage en cascade c'est possible
public class Chat extends AnimalDomestique {

	private String couleurPelage;
	private String race;
	private final int CONSTANTE = 2;
	
	public Chat() {
		
	}
	
	public Chat(String couleurPelage, String race, int nombrePattes , String nom) {
		// super fait référence à la classe mère
		// ici super() représente l'appel au constructeur de la classe mère
		super(nombrePattes, nom);
		this.couleurPelage = couleurPelage;
		this.race = race;
	}
	


	public String getCouleurPelage() {
		return couleurPelage;
	}

	public void setCouleurPelage(String couleurPelage) {
		this.couleurPelage = couleurPelage;
	}

	public String getRace() {
		return race;
	}

	public void setRace(String race) {
		this.race = race;
	}

	@Override
	public void communiquer() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String toString() {
		return "Chat [couleurPelage=" + couleurPelage + ", race=" + race + ", CONSTANTE=" + CONSTANTE + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + CONSTANTE;
		result = prime * result + ((couleurPelage == null) ? 0 : couleurPelage.hashCode());
		result = prime * result + ((race == null) ? 0 : race.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Chat other = (Chat) obj;
		if (CONSTANTE != other.CONSTANTE)
			return false;
		if (couleurPelage == null) {
			if (other.couleurPelage != null)
				return false;
		} else if (!couleurPelage.equals(other.couleurPelage))
			return false;
		if (race == null) {
			if (other.race != null)
				return false;
		} else if (!race.equals(other.race))
			return false;
		return true;
	}
	
	
	
	
	
	
	
	
}
