package fr.dawan.encapsulation;

public class MainEncapsulation {

	public static void main(String[] args) {
		
		Utilisateur user = new Utilisateur();
		
		user.getAge();
	}

}
