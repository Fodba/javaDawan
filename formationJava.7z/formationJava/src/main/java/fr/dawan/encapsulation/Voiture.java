package fr.dawan.encapsulation;

// Classe voiture qui respecte les conventions JavaBean
public class Voiture {
	
	// Variables d'instances
	private String immatriculation;
	private String couleur;
	private String marque;
	
	// Variables de classe
	private static int nombreVoiture;
	
	// Constructeur par défaut
	// Par défaut les variables d'instance sont mis à null pour les String
	Voiture() {
		
	}
	
	// Constructeur surchargé
	Voiture(String immatriculation, String marque, String couleur) {
		this.immatriculation = immatriculation;
		this.marque = marque;
		this.couleur = couleur;
	}
	
	// Autre constructeur surchargé possible, ici la couleur sera toujours fixé à "Blanche"
	Voiture(String immatriculation, String marque) {
		this.immatriculation = immatriculation;
		this.marque = marque;
		this.couleur = "Blanche";
	}
	
	static void afficherNombreVoiture() {
		System.out.println(Voiture.nombreVoiture);
	}

	public String getImmatriculation() {
		return immatriculation;
	}

	public void setImmatriculation(String immatriculation) {
		this.immatriculation = immatriculation;
	}

	public String getCouleur() {
		return couleur;
	}

	public void setCouleur(String couleur) {
		this.couleur = couleur;
	}

	public String getMarque() {
		return marque;
	}

	public void setMarque(String marque) {
		this.marque = marque;
	}

	public static int getNombreVoiture() {
		return nombreVoiture;
	}

	public static void setNombreVoiture(int nombreVoiture) {
		Voiture.nombreVoiture = nombreVoiture;
	}
	
	

}
