package fr.dawan.encapsulation;

// Convention JavaBean
// Au moins un constructeur vide
// Des getters et setters pour tous les attributs private
public class Utilisateur {

	private int age;
	private String nom;
	private String prenom;
	private int testaa;
	
	public Utilisateur() {

	}
	
	public Utilisateur(int age, String nom, String prenom) {
		this.age = age;
		this.nom = nom;
		this.prenom = prenom;
	}

	// un getter convention pour récupérer la valeur de la variable age
	public int getAge() {
		return this.age;
	}

	// un setter convention pour affecter une nouvelle valeur dans age
	public void setAge(int age) {
			if(age > 0){
				this.age = age;
			}
	}

	public String getNom() {
		return nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	
	
}
