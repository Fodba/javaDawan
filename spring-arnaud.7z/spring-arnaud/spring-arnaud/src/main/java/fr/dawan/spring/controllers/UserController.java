package fr.dawan.spring.controllers;

import org.springframework.stereotype.Controller;

@Controller // Annotation pour dire à Spring que cette classe est une servlet
public class UserController {

}
