package fr.dawan.spring.ws;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import fr.dawan.spring.dao.ProductDao;
import fr.dawan.spring.entities.Product;

@RestController
@RequestMapping("/api/produits")
public class ProductWS {

	@Autowired
	private ProductDao productDao;

	public void setProductDao(ProductDao productDao) {
		this.productDao = productDao;
	}

	@GetMapping(produces = "application/json")
	@ResponseBody
	public List<Product> findAll() {
		return productDao.readAll();
	}

	@GetMapping(value = "xml", produces = "application/json")
	@ResponseBody
	public List<Product> findAllXml() {
		return productDao.readAll();
	}

}
