package fr.dawan.exerciceHeritage;

public interface VehiculeAerien {
	
	public boolean isVolant();
	public boolean isRouleFromInterface();

}
