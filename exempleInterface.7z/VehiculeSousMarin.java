package fr.dawan.exerciceHeritage;

public interface VehiculeSousMarin {
	public boolean plonger();
}
